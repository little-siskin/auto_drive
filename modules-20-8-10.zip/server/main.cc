#include "modules/server/socket/socket.h"
#include "modules/common/log.h"
#include "gflags/gflags.h"
#include <memory>

int main(int argc, char *argv[]){
    google::InitGoogleLogging(argv[0]);
    google::ParseCommandLineFlags(&argc, &argv, true);

    std::unique_ptr<Socket> _socket_ptr;
    _socket_ptr.reset(new Socket(4000));

    if(!_socket_ptr->init_socket(argc,argv)){
        std::cout<<"initiate socket error."<<std::endl;
        return 1;
    }
    _socket_ptr->run_socket();
    return 0;
}